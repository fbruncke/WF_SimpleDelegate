﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_SimpleDelegate
{
    /// <summary>
    /// My delegate definition
    /// </summary>
    /// <param name="inumber"></param>
    /// <returns></returns>
    public delegate bool ValidateNumber(int inumber);
}
